import { useEffect, useRef } from "react";

// Faithful WebGL port of the original site's warp-hero animation (same curves, params and shaders).
const P = {
  curve: {
    desktop: {
      outer: [0.562, -0.085, 0.302, 0.145, -0.095, 0.49, -0.179, 1.12],
      inner: [1.118, -0.075, 1.041, 0.165, 0.745, 0.52, 1.007, 1.12],
    },
    mobile: {
      outer: [0.865, 0.275, 0.72, 0.3, 0.47, 0.575, 0.47, 1.15],
      inner: [1.12, 0.315, 0.98, 0.445, 0.83, 0.655, 0.89, 1.15],
    },
  },
  s: { count: 1100, lowWeave: 0.0013, highWeave: 0.00084, drift: 0.009, lfMin: 0.7, lfMax: 2.4, hfMin: 5, hfMax: 12 },
  speed: 0.8,
};
const ASPECT = 2996 / 1686;
const TAU = Math.PI * 2;

type C8 = [number, number, number, number, number, number, number, number];
const bez = (cc: number[], t: number): [number, number] => {
  const c = cc as C8;
  const i = 1 - t, a = i * i * i, b = 3 * i * i * t, d = 3 * i * t * t, e = t * t * t;
  return [c[0] * a + c[2] * b + c[4] * d + c[6] * e, c[1] * a + c[3] * b + c[5] * d + c[7] * e];
};
const lerp2 = (p: number[], q: number[], t: number): [number, number] => [p[0]! + (q[0]! - p[0]!) * t, p[1]! + (q[1]! - p[1]!) * t];

const COMMON = `
precision highp float;
uniform vec2 uResolution;
uniform float uFocus;
vec2 cover(vec2 p){
  vec2 c = vec2(p.x*2.0-1.0, 1.0-p.y*2.0);
  float a = uResolution.x/max(uResolution.y,1.0);
  vec2 s = a > ${ASPECT.toFixed(8)} ? vec2(1.0, a/${ASPECT.toFixed(8)}) : vec2(${ASPECT.toFixed(8)}/a, 1.0);
  vec2 r = c*s; r.x -= (uFocus*2.0-1.0)*s.x; return r;
}`;
const GLOW_V = `${COMMON}
attribute vec2 position; attribute float aProgress; attribute float aCross;
varying float vProgress; varying float vCross;
void main(){ vProgress=aProgress; vCross=aCross; gl_Position=vec4(cover(position),0.0,1.0); }`;
const GLOW_F = `precision highp float;
uniform float uTime;
varying float vProgress; varying float vCross;
void main(){
  float across = pow(max(sin(vCross*3.14159265),0.0),0.8);
  float along = smoothstep(0.008,0.1,vProgress)*(1.0-smoothstep(0.98,1.0,vProgress));
  float breathing = max(0.0, 1.0-0.035+sin(uTime*0.23)*0.035);
  float lift = 0.72 + 0.28*smoothstep(0.15,0.72,vCross);
  // Original palette #3e4139 -> #bbb091, linearized (three.js ColorManagement) to match its direct output
  vec3 color = mix(vec3(0.0482,0.0529,0.0409), vec3(0.4969,0.4342,0.2831), across*lift);
  gl_FragColor = vec4(color, across*along*breathing*0.58);
}`;
const STRAND_V = `${COMMON}
attribute vec2 position; attribute float aProgress; attribute float aSpread; attribute float aSeed; attribute float aOp; attribute float aTone;
varying float vProgress; varying float vSpread; varying float vSeed; varying float vOp; varying float vTone;
void main(){ vProgress=aProgress; vSpread=aSpread; vSeed=aSeed; vOp=aOp; vTone=aTone; gl_Position=vec4(cover(position),0.0,1.0); }`;
const STRAND_F = `precision highp float;
uniform float uTime; uniform float uFreq; uniform float uPhase;
varying float vProgress; varying float vSpread; varying float vSeed; varying float vOp; varying float vTone;
void main(){
  float t = uTime;
  float grain = 0.64 + 0.28*sin(vProgress*680.0 + vSeed*193.0 - t*9.2);
  float p1 = pow(max(0.0, sin(vProgress*uFreq - t*3.2 + uPhase + vSeed*21.0)), 9.0);
  float p2 = pow(max(0.0, sin(vProgress*91.0 - t*7.4 + vSeed*37.0)), 16.0);
  float endFade = smoothstep(0.008,0.055,vProgress)*(1.0-smoothstep(0.965,0.998,vProgress));
  float center = pow(max(sin(vSpread*3.14159265),0.0),1.83);
  float opv = 1.0 + (vOp-0.5)*2.0*0.78;
  float op = (0.08 + center*0.23)*opv;
  float tone = clamp(0.18 + center*0.8 + (vTone-0.5)*0.37, 0.0, 1.0);
  // Original palette #4f5249 -> #c2b595, linearized (three.js ColorManagement) to match its direct output
  vec3 color = mix(vec3(0.0782,0.0844,0.0666), vec3(0.5395,0.4621,0.3005), tone);
  float shimmer = 0.4 + grain*0.35 + p1*1.2 + p2*0.38;
  gl_FragColor = vec4(color, min(0.72, op*shimmer)*endFade);
}`;

function compile(gl: WebGLRenderingContext, vs: string, fs: string) {
  const prog = gl.createProgram()!;
  for (const [type, src] of [[gl.VERTEX_SHADER, vs], [gl.FRAGMENT_SHADER, fs]] as const) {
    const s = gl.createShader(type)!;
    gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || "shader");
    gl.attachShader(prog, s);
  }
  gl.linkProgram(prog);
  return prog;
}

function build(mobile: boolean) {
  const c = mobile ? P.curve.mobile : P.curve.desktop;
  // glow ribbon (triangles)
  const T = 96, X = 18, glow: number[] = [];
  const gv = (i: number, j: number) => { const l = i / T, k = j / X, p = lerp2(bez(c.outer, l), bez(c.inner, l), k); return [p[0], p[1], l, k]; };
  for (let i = 0; i < T; i++) for (let j = 0; j < X; j++) {
    const a = gv(i, j), b = gv(i, j + 1), d = gv(i + 1, j), e = gv(i + 1, j + 1);
    glow.push(...a, ...d, ...b, ...b, ...d, ...e);
  }
  // strands (line pairs)
  const steps = mobile ? 90 : 118, count = mobile ? 420 : P.s.count, s = P.s;
  const outer: number[][] = [], inner: number[][] = [];
  for (let e = 0; e <= steps; e++) { outer.push(bez(c.outer, e / steps)); inner.push(bez(c.inner, e / steps)); }
  let seed = 0x135276e;
  const rnd = () => { let e = (seed += 0x6d2b79f5); e = Math.imul(e ^ (e >>> 15), 1 | e); e ^= e + Math.imul(e ^ (e >>> 7), 61 | e); return ((e ^ (e >>> 14)) >>> 0) / 4294967296; };
  const lines = new Float32Array(count * steps * 2 * 7);
  let o = 0;
  for (let n = 0; n < count; n++) {
    const g = (n + 0.5) * 0.618033988749895 + 0.0015 * rnd(), base = g - Math.floor(g);
    const sd = rnd(), ph = rnd() * TAU, lf = s.lfMin + (s.lfMax - s.lfMin) * rnd(), hf = s.hfMin + (s.hfMax - s.hfMin) * rnd();
    const w = rnd() - 0.5, op = rnd(), tn = rnd();
    const pts: number[][] = [];
    for (let e = 0; e <= steps; e++) {
      const i = e / steps;
      const d = Math.sin(i * TAU * lf + ph) * s.lowWeave + Math.sin(i * TAU * hf + 1.7 * ph) * s.highWeave;
      const sp = Math.min(1, Math.max(0, base + w * s.drift * (i - 0.5) + d));
      const p = lerp2(outer[e]!, inner[e]!, sp);
      pts.push([p[0], p[1], i, sp, sd, op, tn]);
    }
    for (let e = 0; e < steps; e++) { lines.set(pts[e]!, o); o += 7; lines.set(pts[e + 1]!, o); o += 7; }
  }
  return { glow: new Float32Array(glow), lines };
}

export function WarpTrails() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current!;
    const gl = canvas.getContext("webgl", { antialias: true, premultipliedAlpha: false });
    if (!gl) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const gp = compile(gl, GLOW_V, GLOW_F), sp = compile(gl, STRAND_V, STRAND_F);
    // Hover speed-up on the "Book a call" buttons, as on the original.
    const NORMAL = { f: 45, s: P.speed }, HOVER = { f: 20, s: 2.8 };
    let cur = { ...NORMAL }, phase = 0;
    let tr: { from: typeof NORMAL; to: typeof NORMAL; t0: number } | null = null;
    const go = (to: typeof NORMAL) => { tr = { from: { ...cur }, to, t0: performance.now() }; };
    const fine = window.matchMedia("(hover: hover) and (pointer: fine)");
    const triggers = Array.from(canvas.closest("section")?.querySelectorAll<HTMLElement>('[data-hero-warp-hover-trigger], a[href*="calendly.com"]') ?? []);
    const enter = (e: PointerEvent) => { if (fine.matches && e.pointerType !== "touch") go(HOVER); };
    const leave = () => go(NORMAL);
    triggers.forEach((t) => { t.addEventListener("pointerenter", enter); t.addEventListener("pointerleave", leave); });
    const gBuf = gl.createBuffer(), sBuf = gl.createBuffer();
    let gCount = 0, sCount = 0, mobileMode: boolean | null = null, w = 1, h = 1;
    const attr = (prog: WebGLProgram, name: string, size: number, stride: number, off: number) => {
      const loc = gl.getAttribLocation(prog, name); if (loc < 0) return;
      gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, stride * 4, off * 4);
    };
    const resize = () => {
      const mob = window.matchMedia("(max-width: 767px)").matches;
      const dpr = Math.min(mob ? 1.5 : 2, window.devicePixelRatio || 1);
      w = Math.max(1, canvas.clientWidth); h = Math.max(1, canvas.clientHeight);
      canvas.width = w * dpr; canvas.height = h * dpr;
      gl.viewport(0, 0, canvas.width, canvas.height);
      const m = w / h < 0.75;
      if (m !== mobileMode) {
        mobileMode = m;
        const { glow, lines } = build(m);
        gl.bindBuffer(gl.ARRAY_BUFFER, gBuf); gl.bufferData(gl.ARRAY_BUFFER, glow, gl.STATIC_DRAW); gCount = glow.length / 4;
        gl.bindBuffer(gl.ARRAY_BUFFER, sBuf); gl.bufferData(gl.ARRAY_BUFFER, lines, gl.STATIC_DRAW); sCount = lines.length / 7;
      }
    };
    const focus = () => { const a = w / h; return a < 0.75 ? 0.72 : a < 1.2 ? 0.62 : 0.5; };
    const setU = (prog: WebGLProgram, t: number) => {
      gl.useProgram(prog);
      gl.uniform2f(gl.getUniformLocation(prog, "uResolution"), w, h);
      gl.uniform1f(gl.getUniformLocation(prog, "uFocus"), focus());
      gl.uniform1f(gl.getUniformLocation(prog, "uTime"), t);
      gl.uniform1f(gl.getUniformLocation(prog, "uFreq"), cur.f);
      gl.uniform1f(gl.getUniformLocation(prog, "uPhase"), phase);
    };
    const render = (t: number) => {
      gl.clearColor(1 / 255, 4 / 255, 5 / 255, 1); gl.clear(gl.COLOR_BUFFER_BIT);
      gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
      setU(gp, t); gl.bindBuffer(gl.ARRAY_BUFFER, gBuf);
      attr(gp, "position", 2, 4, 0); attr(gp, "aProgress", 1, 4, 2); attr(gp, "aCross", 1, 4, 3);
      gl.drawArrays(gl.TRIANGLES, 0, gCount);
      setU(sp, t); gl.bindBuffer(gl.ARRAY_BUFFER, sBuf);
      attr(sp, "position", 2, 7, 0); attr(sp, "aProgress", 1, 7, 2); attr(sp, "aSpread", 1, 7, 3);
      attr(sp, "aSeed", 1, 7, 4); attr(sp, "aOp", 1, 7, 5); attr(sp, "aTone", 1, 7, 6);
      gl.drawArrays(gl.LINES, 0, sCount);
    };
    let time = 0, prev: number | null = null, raf = 0;
    const tick = (now: number) => {
      const dt = prev === null ? 0 : Math.min((now - prev) / 1000, 0.05);
      prev = now;
      if (tr) {
        const k = Math.min(1, (now - tr.t0) / 1600), e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
        const nf = tr.from.f + (tr.to.f - tr.from.f) * e;
        if (nf > cur.f) phase = (phase - (nf - cur.f)) % TAU;
        cur = { f: nf, s: tr.from.s + (tr.to.s - tr.from.s) * e };
        if (k >= 1) tr = null;
      }
      time += dt * cur.s; render(time);
      raf = requestAnimationFrame(tick);
    };
    resize();
    if (reduce) render(0.72); else raf = requestAnimationFrame(tick);
    const ro = new ResizeObserver(() => { resize(); if (reduce) render(0.72); });
    ro.observe(canvas);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); triggers.forEach((t) => { t.removeEventListener("pointerenter", enter); t.removeEventListener("pointerleave", leave); }); };
  }, []);
  return <canvas ref={ref} aria-hidden="true" style={{ display: "block", width: "100%", height: "100%" }} />;
}
